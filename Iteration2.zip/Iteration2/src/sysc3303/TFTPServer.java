package sysc3303;

import java.util.Scanner;

public class TFTPServer {
	
    public static String DEFAULT_FILE_PATH =System.getProperty("user.dir")+ "\\server\\" + "\\files\\";
    private String filePath;

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TFTPServer newServer = new TFTPServer();
		Thread c = new  TFTPServerListener(); 
        c.start();
        String x;
        Scanner sc= new Scanner (System.in);
     
        while(true){
        	// Ask to shutdown 
        	System.out.println("In order to shutdown the server, press (Y) during the prompt.");
	        System.out.println("Shutdown the server? (Y|N)");
	        x = sc.next();
	        // If operator says yes then the server shutdown as threads act independently of the server once created.
	        if (x.contains("Y")|| x.contains("y")){
	            System.out.println("Server is now shutting down.");
	            sc.reset();
	            ((TFTPServerListener) c).setStatus();
	            c.interrupt();
	            System.exit(0);
	        }
	        
	        //prompt user for server path
	        System.out.println("------------------------------------------------------");
			System.out.println("File path selection: \n");
			System.out.println("Enter the name of the file path for the Server to use (if * is typed then src/server/files/ will be used):");

			newServer.filePath = sc.next();
			
			if (newServer.filePath.trim().equals("*")) {
				sc.reset();
				newServer.filePath = DEFAULT_FILE_PATH;
			}
			
			//Check that file path exists/is a valid directory
			if (new File(newServer.filePath).isDirectory()){
				break;
			} else {
				System.out.println("File path does not exist or is not a directory, try again.");
			}
        }
        
	}
}
